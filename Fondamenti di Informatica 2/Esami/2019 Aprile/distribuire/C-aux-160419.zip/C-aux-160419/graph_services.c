#include <stdlib.h>

#include "graph_services.h"
#include "graph.h"
#include "linked_list.h"

int conn_comp(graph* g){
	/*DA IMPLEMENTARE*/
	return 0;
}

void contract(graph* g){
	/*DA IMPLEMENTARE*/
}

int count_k3(graph* g){
	/*DA IMPLEMENTARE*/
	return 0;
}