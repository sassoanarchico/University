public class GraphServices {

	/**
 	* Dato un grafo g, la funziona ritorna il numero delle sue componenti connesse.
	*/
	public static int connComp(Graph g){
		/*DA IMPLEMENTARE*/
		return 0;
	}

	/**
	 * Dato un grafo g, la funzione modifica il grafo contraendone tutti i vertici di grado 2.
	 */ 
	public static void contract(Graph g){
		/*DA IMPLEMENTARE*/
	}

	/**
	 * Dato un grafo g, ritorna il numero di sottografi completi di 3 nodi contenuti in g
	 */
	public static int countK3(Graph g){
		/*DA IMPLEMENTARE*/
		return 0;
	}
}