//#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "bst.h"


void ordina (bst *b) {
    /* DA IMPLEMENTARE */
    return;
}


void outer_range(bst *t, int k1, int k2) {
    /* DA IMPLEMENTARE */
    return;
}


int altezza(bst *b) {
    /* DA IMPLEMENTARE */
    return -3; // solo x restituire un valore anomalo
}
