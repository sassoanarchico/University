import java.util.Random;

public class GraphServices {

	/**
 	 * Dato un grafo g, rappresentato mediante matrice di adiacenze, ritornare il grafo g'
 	 * che e' uguale a g, ma e' rappresentato mediante lista di incidenze.
	 */
	public static Graph mat2list(int[][] mat){
		/*DA IMPLEMENTARE*/
		return null;
	}

	/**
	 * Dato un grafo in input, la funziona ritorna 1 se il grafo e' fortemente connesso, 0 altrimenti.
	 */
	public static int isStronglyConnected(Graph g){
		/*DA IMPLEMENTARE*/
		return 0;
	}

	/**
 	 * Dato un grafo g, ritornare 1 se il grafo e' uguale alla sua chiusura transitiva, 0 altrimenti. 
	 */ 
	public static int isClosed(Graph g) {
		/*DA IMPLEMENTARE*/
		return 0;
	}
	
	@SuppressWarnings("unused")
	private static char char_gen() {
		Random rnd = new Random();
		int n = rnd.nextInt(26) + 65;
		return (char) n;
	}
}