import java.util.*;

public class BSTServices {

	public LinkedList ordina(BST t) {

	// DA IMPLEMENTARE
		return null;
		
	}
		
	public LinkedList outer_range(BST t, int k1, int k2) {

	// DA IMPLEMENTARE
		return null;

	}
	
	public int altezza(BST t) {

	// DA IMPLEMENTARE
		return -1;

	}
	
}
