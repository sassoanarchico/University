#ifndef __GRAPH_SERVICES__
#define __GRAPH_SERVICES__

#include "graph.h"

void bfs(graph*, graph_node*);

void sssp(graph*, graph_node*);

void apsp(graph*);

#endif // !__GRAPH_SERVICES__
