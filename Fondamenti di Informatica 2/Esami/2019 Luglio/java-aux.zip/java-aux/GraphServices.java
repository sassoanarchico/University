import java.util.*;

public class GraphServices {


	public static <V> void bfs(Graph<V> g, Node<V> source) {
		// DA IMPLEMENTARE
	}

	public static <V> String sssp(Graph<V> g, Node<V> source) {
		// DA IMPLEMENTARE
			return "";
	}

	public static <V> void apsp(Graph<V> g) {
		// DA IMPLEMENTARE
	}
}
